# Dynasty Hub V2

Upload index.html, styles.css, and app.js to the root of the Dynasty-Hub repository.

League ID: 1327325072385409024

Uses the public Sleeper API and Dynasty Dealer market API. Data is cached locally for 24 hours. Trade grades are currently a market-balance baseline; the full contextual/historical engine is intentionally not fabricated without historical inputs.
